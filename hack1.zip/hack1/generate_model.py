import pandas as pd
import numpy as np
import pickle
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
import re

print("Creating fraud detection model...")

# Generate synthetic data for training
n_samples = 5000
np.random.seed(42)

# Create basic transaction features
data = {
    'Amount': np.random.exponential(1000, n_samples),
    'Time': np.random.randint(0, 24*60*60, n_samples),
    'ProcessingTime': np.random.randint(1, 300, n_samples),  # Processing time in seconds
    'TransactionType': np.random.choice(['Credit', 'Debit', 'Transfer'], n_samples),
    'SenderAccount': np.random.choice([f'ACC-{i:04d}' for i in range(500)], n_samples),  # Updated format ACC-NNNN
    'ReceiverAccount': np.random.choice([f'ACC-{i:04d}' for i in range(500)], n_samples),  # Updated format ACC-NNNN
    'Location': np.random.choice(['local', 'domestic', 'international'], n_samples),
    'DeviceID': np.random.choice([f'DEV{i}' for i in range(300)], n_samples),
    'IP_Address': np.random.choice([f'192.168.1.{i}' for i in range(200)], n_samples),
    'PreviousTransactionCount': np.random.poisson(10, n_samples),
    'AccountAge': np.random.randint(1, 1000, n_samples),
    'TransactionMode': np.random.choice(['Online', 'ATM', 'POS', 'Mobile'], n_samples)
}

# Create DataFrame
df = pd.DataFrame(data)

# Feature Engineering
# 1. Create frequency features (for outlier detection)
for field in ["SenderAccount", "ReceiverAccount", "IP_Address", "DeviceID"]:
    freq = df[field].value_counts()
    df[f"{field}_freq"] = df[field].map(freq)

# 2. Amount features
df['AmountLog'] = np.log1p(df['Amount'])

# Create amount z-score
df['Amount_zscore'] = (df['Amount'] - df['Amount'].mean()) / df['Amount'].std()

# Create amount bins
df['AmountBin'] = pd.qcut(df['Amount'], 10, labels=False)

# 3. Add processing time-related features
# Adjust processing time to be realistic (larger amounts take longer)
df['ProcessingTime'] = df['ProcessingTime'] + df['Amount'] / 100

# Create processing time vs. amount features
df['ProcessingTime_per_amount'] = df['ProcessingTime'] / df['Amount']
df['ProcessingTime_z'] = (df['ProcessingTime'] - df['ProcessingTime'].mean()) / df['ProcessingTime'].std()

# Add suspicious processing time flags
# Large amounts with fast processing
df['suspicious_fast_large'] = ((df['Amount'] > 5000) & (df['ProcessingTime'] < 30)).astype(int)
# Small amounts with slow processing  
df['suspicious_slow_small'] = ((df['Amount'] < 100) & (df['ProcessingTime'] > 120)).astype(int)
# Medium transactions with unusual timing
df['suspicious_medium_timing'] = ((df['Amount'] > 500) & (df['Amount'] < 2000) & 
                                 ((df['ProcessingTime'] < 10) | (df['ProcessingTime'] > 180))).astype(int)

# 4. Account validation and suspicious patterns
# Validate account format (ACC-NNNN pattern)
account_pattern = r'^ACC-\d{4}$'
df['valid_sender_format'] = df['SenderAccount'].str.match(account_pattern).astype(int)
df['valid_receiver_format'] = df['ReceiverAccount'].str.match(account_pattern).astype(int)

# Detect suspicious account keywords
suspicious_keywords = ['TEST', 'TEMP', 'FRAUD', 'HACK']
df['suspicious_sender_keyword'] = df['SenderAccount'].apply(
    lambda x: any(keyword in x for keyword in suspicious_keywords)).astype(int)
df['suspicious_receiver_keyword'] = df['ReceiverAccount'].apply(
    lambda x: any(keyword in x for keyword in suspicious_keywords)).astype(int)

# 5. IP address outlier detection
# Create flag for suspicious IP patterns (internal networks, reserved ranges)
suspicious_ip_prefixes = ['10.', '192.168.', '127.0.0.', '169.254.', '0.0.0.', '203.0.113.', '198.51.100.', '192.0.2.']
df['suspicious_ip_pattern'] = df['IP_Address'].apply(
    lambda x: any(x.startswith(prefix) for prefix in suspicious_ip_prefixes)).astype(int)

# Define rare IP as potential outlier (bottom 1% frequency)
rare_ip_threshold = df['IP_Address_freq'].quantile(0.01)
df['rare_ip_outlier'] = (df['IP_Address_freq'] <= rare_ip_threshold).astype(int)

# Create risk percentage feature based on all factors
df['risk_percentage'] = (
    (df['Amount_zscore'] > 2) * 20 +                          # High amount scores
    df['suspicious_fast_large'] * 15 +                        # Processing time anomalies
    df['suspicious_slow_small'] * 10 + 
    df['suspicious_medium_timing'] * 12 +
    (1 - df['valid_sender_format']) * 15 +                    # Invalid account format
    (1 - df['valid_receiver_format']) * 15 +
    df['suspicious_sender_keyword'] * 25 +                    # Suspicious account keywords
    df['suspicious_receiver_keyword'] * 25 +
    (df['SenderAccount_freq'] <= rare_ip_threshold) * 10 +    # Rare accounts
    (df['ReceiverAccount_freq'] <= rare_ip_threshold) * 10 +
    df['suspicious_ip_pattern'] * 15 +                        # Suspicious IP
    df['rare_ip_outlier'] * 10 +                              # Rare IP
    (df['Amount'] > 5000) * 5 +                               # Base amount risk
    (df['ProcessingTime'] < 10) * 5                           # Very fast processing
)

# Cap risk percentage at 100%
df['risk_percentage'] = df['risk_percentage'].clip(0, 100)

# Generate synthetic fraud labels based on rules and risk percentage
# Automatically mark as fraudulent if risk percentage > 60%
df['isFraud'] = (df['risk_percentage'] > 60).astype(int)

# Add some additional fraud patterns for training
additional_fraud_prob = (
    (df['Amount'] > df['Amount'].quantile(0.8)) * 0.4 +
    (df['Location'] == 'international') * 0.5 +
    (df['PreviousTransactionCount'] < 3) * 0.3 +
    (df['AccountAge'] < 30) * 0.3 +
    (df['IP_Address_freq'] == 1) * 0.4 +
    (df['DeviceID_freq'] == 1) * 0.3 +
    (df['TransactionType'] == 'Debit') * 0.2 +
    ((df['Amount'] > 5000) & (df['PreviousTransactionCount'] < 5)) * 0.6 +
    ((df['Amount'] > 1000) & (df['AccountAge'] < 20)) * 0.5 +
    ((df['TransactionType'] == 'Transfer') & (df['Amount'] > 3000)) * 0.4 +
    ((df['TransactionMode'] == 'Online') & (df['IP_Address_freq'] == 1)) * 0.5
)

# Normalize probabilities
additional_fraud_prob = additional_fraud_prob / additional_fraud_prob.max()

# Add more frauds where risk_percentage <= 60 but other patterns suggest fraud
df.loc[(df['isFraud'] == 0) & (additional_fraud_prob > 0.7), 'isFraud'] = 1

print(f"Generated dataset with {len(df)} records and {df['isFraud'].sum()} fraudulent transactions")
print(f"Fraud rate: {df['isFraud'].mean() * 100:.2f}%")

# Define categorical columns
categorical_columns = ['TransactionType', 'Location', 'TransactionMode', 'SenderAccount', 
                       'ReceiverAccount', 'DeviceID', 'IP_Address']

# Apply label encoding to categorical columns
encoders = {}
for col in categorical_columns:
    le = LabelEncoder()
    df[col] = le.fit_transform(df[col])
    encoders[col] = le

# Split features and target
X = df.drop(['isFraud'], axis=1)
y = df['isFraud']

# Save column names
features = list(X.columns)

# Split into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Normalize features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Train a RandomForest model
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train_scaled, y_train)

# Evaluate the model
train_score = model.score(X_train_scaled, y_train)
test_score = model.score(X_test_scaled, y_test)

print(f"Model accuracy - Training: {train_score:.4f}, Testing: {test_score:.4f}")

# Get feature importances
feature_importances = pd.DataFrame({
    'Feature': features,
    'Importance': model.feature_importances_
}).sort_values('Importance', ascending=False)

print("\nTop 10 most important features:")
print(feature_importances.head(10))

# Save the model, scaler, encoders, and feature list to a pickle file
model_data = {
    "model": model,
    "scaler": scaler,
    "encoders": encoders,
    "features": features,
    "categorical_columns": categorical_columns,
    "risk_threshold": 60  # Risk threshold for automatic fraud detection (60%)
}

with open("fraud_model.pkl", "wb") as f:
    pickle.dump(model_data, f)

print("\nModel saved as fraud_model.pkl")
print("This file contains:")
print("- Trained RandomForest model")
print("- StandardScaler")
print("- LabelEncoders for categorical variables")
print("- List of feature names")
print("- List of categorical column names")
print("- Risk threshold for automatic fraud detection") 