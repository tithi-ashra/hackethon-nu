document.addEventListener("DOMContentLoaded", function() {
    // References to DOM elements
    const adminTransactionList = document.getElementById("admin-transaction-list");
    const totalTransactionsEl = document.getElementById("total-transactions");
    const fraudTransactionsEl = document.getElementById("fraud-transactions");
    const safeTransactionsEl = document.getElementById("safe-transactions");
    const successRateEl = document.getElementById("success-rate");
    const timeRangeFilter = document.getElementById("timeRangeFilter");
    const riskLevelFilter = document.getElementById("riskLevelFilter");
    const applyFiltersBtn = document.getElementById("applyFilters");
    const userActivityList = document.getElementById("user-activity-list");
    const saveRulesBtn = document.getElementById("save-rules");
    
    // Load the transactions from localStorage
    let allTransactions = [];
    try {
        const savedTransactions = localStorage.getItem('transactions');
        if (savedTransactions) {
            allTransactions = JSON.parse(savedTransactions);
        }
        
        // Update dashboard statistics
        updateDashboardStats(allTransactions);
        
        // Render transactions table
        renderTransactionsTable(allTransactions);
        
        // Log the transaction data load as a user activity
        logUserActivity("Admin loaded transaction data", "data_load");
    } catch (error) {
        console.error("Error loading transactions:", error);
    }
    
    // Load user activity from localStorage
    loadUserActivities();
    
    // Load detection rules from localStorage
    loadDetectionRules();
    
    // Event Listeners
    if (applyFiltersBtn) {
        applyFiltersBtn.addEventListener("click", function() {
            const timeRange = timeRangeFilter.value;
            const riskLevel = riskLevelFilter.value;
            filterTransactions(timeRange, riskLevel);
            
            // Log filter application as user activity
            logUserActivity(`Applied filters: ${timeRange}, ${riskLevel}`, "filter_application");
        });
    }
    
    if (saveRulesBtn) {
        saveRulesBtn.addEventListener("click", function() {
            saveDetectionRules();
            alert("Detection rules saved successfully!");
            
            // Log rules change as user activity
            logUserActivity("Updated detection rules", "rules_update");
        });
    }
    
    // Function to update dashboard statistics
    function updateDashboardStats(transactions) {
        if (!totalTransactionsEl || !fraudTransactionsEl || !safeTransactionsEl || !successRateEl) {
            return;
        }
        
        const totalCount = transactions.length;
        const fraudCount = transactions.filter(tx => tx.status === "Fraud").length;
        const safeCount = transactions.filter(tx => tx.status === "Safe").length;
        const successRate = totalCount > 0 ? Math.round((safeCount / totalCount) * 100) : 0;
        
        totalTransactionsEl.textContent = totalCount;
        fraudTransactionsEl.textContent = fraudCount;
        safeTransactionsEl.textContent = safeCount;
        successRateEl.textContent = `${successRate}%`;
    }
    
    // Function to render transactions in the admin table
    function renderTransactionsTable(transactions) {
        if (!adminTransactionList) {
            return;
        }
        
        adminTransactionList.innerHTML = "";
        
        if (transactions.length === 0) {
            adminTransactionList.innerHTML = `<tr><td colspan="7" style="text-align: center;">No transactions found</td></tr>`;
            return;
        }
        
        transactions.forEach(tx => {
            const row = document.createElement("tr");
            const riskClass = tx.risk > 70 ? "high-risk" : tx.risk > 30 ? "medium-risk" : "low-risk";
            
            row.innerHTML = `
                <td>${tx.id}</td>
                <td>$${tx.amount.toFixed(2)}</td>
                <td>${tx.type}</td>
                <td>${tx.timestamp}</td>
                <td><span class="${riskClass}">${tx.risk}%</span></td>
                <td><span class="status-badge ${tx.status.toLowerCase()}">${tx.status}</span></td>
                <td>
                    <button class="view-details-btn" data-id="${tx.id}">View Details</button>
                </td>
            `;
            
            adminTransactionList.appendChild(row);
        });
        
        // Add event listeners to the view details buttons
        const viewDetailsButtons = document.querySelectorAll(".view-details-btn");
        viewDetailsButtons.forEach(btn => {
            btn.addEventListener("click", function() {
                const txId = this.getAttribute("data-id");
                showTransactionDetails(txId);
                
                // Log view details as user activity
                logUserActivity(`Viewed details for transaction ${txId}`, "view_details");
            });
        });
    }
    
    // Function to show transaction details and AI insights
    function showTransactionDetails(transactionId) {
        const transaction = allTransactions.find(tx => tx.id === transactionId);
        
        if (!transaction) {
            return;
        }
        
        const detailsContainer = document.getElementById("selected-transaction-details");
        const anomalyDetails = document.getElementById("anomaly-details");
        const anomalyFactors = document.getElementById("anomaly-factors");
        const complianceDetails = document.getElementById("compliance-details");
        const complianceSummary = document.getElementById("compliance-summary");
        
        if (detailsContainer) {
            detailsContainer.innerHTML = `
                <h3>Transaction ${transaction.id}</h3>
                <p><strong>Amount:</strong> $${transaction.amount.toFixed(2)}</p>
                <p><strong>Type:</strong> ${transaction.type}</p>
                <p><strong>From:</strong> ${transaction.sender}</p>
                <p><strong>To:</strong> ${transaction.receiver}</p>
                <p><strong>Time:</strong> ${transaction.timestamp}</p>
                <p><strong>Risk Score:</strong> ${transaction.risk}%</p>
                <p><strong>Status:</strong> ${transaction.status}</p>
            `;
        }
        
        // Generate anomaly insights based on the transaction
        if (anomalyDetails && anomalyFactors && transaction.risk > 30) {
            anomalyDetails.style.display = "block";
            
            // Generate contextual insights based on transaction data
            const insights = generateAnomalyInsights(transaction);
            
            anomalyFactors.innerHTML = "";
            insights.forEach(insight => {
                const insightEl = document.createElement("div");
                insightEl.className = "anomaly-detail-item";
                insightEl.innerHTML = `
                    <span>${insight.factor}:</span> ${insight.description}
                    <div class="risk-contribution">Contribution to risk: ${insight.contribution}%</div>
                `;
                anomalyFactors.appendChild(insightEl);
            });
        } else if (anomalyDetails) {
            anomalyDetails.style.display = "none";
        }
        
        // Generate compliance analysis
        if (complianceDetails && complianceSummary) {
            complianceDetails.style.display = "block";
            
            // Check for compliance issues
            const complianceIssues = checkComplianceIssues(transaction);
            
            if (complianceIssues.length > 0) {
                complianceSummary.innerHTML = `
                    <div class="compliance-warning">
                        <strong>Compliance Issues Detected:</strong>
                        <ul>
                            ${complianceIssues.map(issue => `<li>${issue}</li>`).join('')}
                        </ul>
                        <p>Recommended Action: Further investigation required.</p>
                    </div>
                `;
            } else {
                complianceSummary.innerHTML = `
                    <div class="compliance-pass">
                        <strong>No Compliance Issues Detected</strong>
                        <p>This transaction appears to comply with all financial regulations.</p>
                    </div>
                `;
            }
        }
    }
    
    // Function to generate anomaly insights for a transaction
    function generateAnomalyInsights(transaction) {
        const insights = [];
        
        // Check for large amount
        if (transaction.amount > 5000) {
            insights.push({
                factor: "Large Amount",
                description: `Transaction amount ($${transaction.amount.toFixed(2)}) is unusually large.`,
                contribution: 25
            });
        }
        
        // Check for time-based anomalies
        const txTime = parseTimeFromTimestamp(transaction.timestamp);
        if (isLateNightTime(txTime)) {
            insights.push({
                factor: "Unusual Time",
                description: "Transaction occurred during late night hours (11 PM - 5 AM).",
                contribution: 20
            });
        }
        
        // Check for account format issues
        const accountPattern = /^ACC-\d{4}$/;
        if (!accountPattern.test(transaction.sender)) {
            insights.push({
                factor: "Invalid Sender Format",
                description: `Sender account "${transaction.sender}" does not match the expected format (ACC-NNNN).`,
                contribution: 30
            });
        }
        
        if (!accountPattern.test(transaction.receiver)) {
            insights.push({
                factor: "Invalid Receiver Format",
                description: `Receiver account "${transaction.receiver}" does not match the expected format (ACC-NNNN).`,
                contribution: 30
            });
        }
        
        // Check for pattern-based anomalies
        if (checkForRapidSuccessionTransactions(transaction)) {
            insights.push({
                factor: "Rapid Succession",
                description: "Multiple transactions from same sender in a short time period.",
                contribution: 15
            });
        }
        
        // If no specific insights found but risk is high, add a generic one
        if (insights.length === 0 && transaction.risk > 70) {
            insights.push({
                factor: "AI Pattern Detection",
                description: "Machine learning model detected unusual patterns compared to normal transaction behavior.",
                contribution: 60
            });
        }
        
        return insights;
    }
    
    // Function to check for compliance issues
    function checkComplianceIssues(transaction) {
        const issues = [];
        
        // Check for AML (Anti Money Laundering) thresholds
        if (transaction.amount >= 10000) {
            issues.push("Transaction exceeds AML reporting threshold ($10,000) and requires regulatory reporting.");
        }
        
        // Check for structured transactions (potential AML avoidance)
        if (checkForStructuredTransactions(transaction)) {
            issues.push("Potential structured transactions detected - multiple related transactions below reporting thresholds.");
        }
        
        // Check for international transfers compliance
        if (isInternationalTransaction(transaction)) {
            issues.push("International transaction requires additional SWIFT/BIC code verification and potentially OFAC screening.");
        }
        
        // Check for high-risk jurisdiction transfers
        if (isHighRiskJurisdiction(transaction)) {
            issues.push("Transaction involves entities in high-risk jurisdictions subject to enhanced due diligence.");
        }
        
        return issues;
    }
    
    // Helper function to parse time from timestamp
    function parseTimeFromTimestamp(timestamp) {
        // Assuming timestamp format like "04/15/2023 09:45 AM"
        try {
            const timePart = timestamp.split(" ")[1];
            const amPm = timestamp.split(" ")[2];
            const [hours, minutes] = timePart.split(":");
            
            let hour = parseInt(hours);
            if (amPm === "PM" && hour < 12) {
                hour += 12;
            } else if (amPm === "AM" && hour === 12) {
                hour = 0;
            }
            
            return { hour, minutes: parseInt(minutes) };
        } catch (error) {
            console.error("Error parsing timestamp:", error);
            return { hour: 12, minutes: 0 }; // Default fallback
        }
    }
    
    // Helper function to check if time is late night (11 PM - 5 AM)
    function isLateNightTime(timeObj) {
        return (timeObj.hour >= 23 || timeObj.hour <= 5);
    }
    
    // Helper function to check for rapid succession transactions
    function checkForRapidSuccessionTransactions(transaction) {
        // This would be more sophisticated in a real system
        const senderAccount = transaction.sender;
        const txTime = new Date(transaction.timestamp);
        
        // Count transactions from the same sender within 5 minutes
        const relatedTx = allTransactions.filter(tx => {
            if (tx.id === transaction.id) return false; // Skip the current transaction
            if (tx.sender !== senderAccount) return false; // Must be from same sender
            
            // Check if within 5 minutes (simplified)
            const otherTxTime = new Date(tx.timestamp);
            const timeDiff = Math.abs(txTime - otherTxTime) / (1000 * 60); // Difference in minutes
            return timeDiff <= 5;
        });
        
        return relatedTx.length >= 2; // Flag if 3 or more transactions (including this one)
    }
    
    // Helper function to check for structured transactions (AML avoidance)
    function checkForStructuredTransactions(transaction) {
        // Look for multiple transactions just below reporting thresholds
        const senderAccount = transaction.sender;
        const receiverAccount = transaction.receiver;
        
        // Count transactions between same parties with amounts just below reporting thresholds
        const relatedTx = allTransactions.filter(tx => {
            if (tx.id === transaction.id) return false; // Skip the current transaction
            
            // Same parties involved
            const sameSender = tx.sender === senderAccount;
            const sameReceiver = tx.receiver === receiverAccount;
            
            // Amount just below thresholds (e.g., $8,000-$9,999)
            const suspiciousAmount = tx.amount >= 8000 && tx.amount < 10000;
            
            return (sameSender || sameReceiver) && suspiciousAmount;
        });
        
        return relatedTx.length >= 1; // Flag if 2 or more such transactions (including this one)
    }
    
    // Helper function to check if it's an international transaction
    function isInternationalTransaction(transaction) {
        // Simplified check - in a real system this would be more sophisticated
        return transaction.sender.startsWith("ACC-") && !transaction.receiver.startsWith("ACC-") ||
               !transaction.sender.startsWith("ACC-") && transaction.receiver.startsWith("ACC-");
    }
    
    // Helper function to check if transaction involves high-risk jurisdiction
    function isHighRiskJurisdiction(transaction) {
        // Simplified check - in a real system this would check against a database of high-risk countries
        const highRiskPatterns = ["INTL-", "OFF-"];
        
        return highRiskPatterns.some(pattern => 
            transaction.sender.includes(pattern) || transaction.receiver.includes(pattern)
        );
    }
    
    // Function to filter transactions based on selected criteria
    function filterTransactions(timeRange, riskLevel) {
        let filtered = [...allTransactions];
        
        // Apply time range filter
        if (timeRange !== "all") {
            const now = new Date();
            const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
            const thisWeekStart = new Date(today);
            thisWeekStart.setDate(today.getDate() - today.getDay()); // Start of week (Sunday)
            const thisMonthStart = new Date(now.getFullYear(), now.getMonth(), 1);
            
            filtered = filtered.filter(tx => {
                const txDate = new Date(tx.timestamp);
                
                if (timeRange === "today") {
                    return txDate >= today;
                } else if (timeRange === "week") {
                    return txDate >= thisWeekStart;
                } else if (timeRange === "month") {
                    return txDate >= thisMonthStart;
                }
                
                return true;
            });
        }
        
        // Apply risk level filter
        if (riskLevel !== "all") {
            filtered = filtered.filter(tx => {
                if (riskLevel === "high") {
                    return tx.risk > 70;
                } else if (riskLevel === "medium") {
                    return tx.risk >= 30 && tx.risk <= 70;
                } else if (riskLevel === "low") {
                    return tx.risk < 30;
                }
                return true;
            });
        }
        
        // Update the transaction list
        renderTransactionsTable(filtered);
        
        // Also update statistics based on filtered transactions
        updateDashboardStats(filtered);
    }
    
    // Function to log user activity
    function logUserActivity(description, activityType) {
        const activity = {
            id: generateActivityId(),
            timestamp: new Date().toLocaleString(),
            description: description,
            type: activityType
        };
        
        // Get existing activities or initialize
        let activities = [];
        try {
            const savedActivities = localStorage.getItem('userActivities');
            if (savedActivities) {
                activities = JSON.parse(savedActivities);
            }
        } catch (error) {
            console.error("Error loading user activities:", error);
        }
        
        // Add new activity to the beginning
        activities.unshift(activity);
        
        // Limit to last 100 activities to prevent storage issues
        if (activities.length > 100) {
            activities = activities.slice(0, 100);
        }
        
        // Save back to localStorage
        localStorage.setItem('userActivities', JSON.stringify(activities));
        
        // Update the activity list display
        if (userActivityList) {
            renderUserActivities(activities);
        }
    }
    
    // Function to generate a unique activity ID
    function generateActivityId() {
        return "ACT-" + Date.now().toString().slice(-6);
    }
    
    // Function to load and display user activities
    function loadUserActivities() {
        if (!userActivityList) {
            return;
        }
        
        let activities = [];
        try {
            const savedActivities = localStorage.getItem('userActivities');
            if (savedActivities) {
                activities = JSON.parse(savedActivities);
            }
        } catch (error) {
            console.error("Error loading user activities:", error);
        }
        
        renderUserActivities(activities);
    }
    
    // Function to render user activities in the list
    function renderUserActivities(activities) {
        if (!userActivityList) {
            return;
        }
        
        userActivityList.innerHTML = "";
        
        if (activities.length === 0) {
            userActivityList.innerHTML = `<div class="activity-item">No activity recorded yet</div>`;
            return;
        }
        
        activities.forEach(activity => {
            const activityEl = document.createElement("div");
            activityEl.className = "activity-item";
            
            activityEl.innerHTML = `
                <div>${activity.description}</div>
                <div class="time">${activity.timestamp}</div>
            `;
            
            userActivityList.appendChild(activityEl);
        });
    }
    
    // Function to load detection rules from localStorage
    function loadDetectionRules() {
        try {
            const savedRules = localStorage.getItem('detectionRules');
            if (savedRules) {
                const rules = JSON.parse(savedRules);
                
                // Apply the rules to the form
                document.getElementById("rule-large-amount").checked = rules.flagLargeAmount;
                document.getElementById("large-amount-threshold").value = rules.largeAmountThreshold;
                document.getElementById("rule-night-transactions").checked = rules.flagNightTransactions;
                document.getElementById("rule-rapid-succession").checked = rules.flagRapidSuccession;
                document.getElementById("succession-minutes").value = rules.rapidSuccessionMinutes;
                document.getElementById("rule-account-validation").checked = rules.validateAccountFormat;
                document.getElementById("rule-ml-model").checked = rules.useMlModel;
            }
        } catch (error) {
            console.error("Error loading detection rules:", error);
        }
    }
    
    // Function to save detection rules to localStorage
    function saveDetectionRules() {
        const rules = {
            flagLargeAmount: document.getElementById("rule-large-amount").checked,
            largeAmountThreshold: parseInt(document.getElementById("large-amount-threshold").value),
            flagNightTransactions: document.getElementById("rule-night-transactions").checked,
            flagRapidSuccession: document.getElementById("rule-rapid-succession").checked,
            rapidSuccessionMinutes: parseInt(document.getElementById("succession-minutes").value),
            validateAccountFormat: document.getElementById("rule-account-validation").checked,
            useMlModel: document.getElementById("rule-ml-model").checked
        };
        
        localStorage.setItem('detectionRules', JSON.stringify(rules));
        
        // This would be used by the detection algorithm
        window.detectionRules = rules;
    }
}); 