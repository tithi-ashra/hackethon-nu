document.addEventListener("DOMContentLoaded", function () {
    // Toggle Dark Mode
    const darkModeToggle = document.getElementById("dark-mode-toggle");
    if (darkModeToggle) {
        // Check for saved theme preference
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme === 'dark') {
            document.body.classList.add('dark-mode');
        }
        
        darkModeToggle.addEventListener("click", function () {
            document.body.classList.toggle("dark-mode");
            // Save theme preference
            if (document.body.classList.contains('dark-mode')) {
                localStorage.setItem('theme', 'dark');
            } else {
                localStorage.setItem('theme', 'light');
            }
        });
    }
    
    // Check if user is logged in and update UI accordingly
    const currentUser = localStorage.getItem('currentUser');
    if (currentUser) {
        // User is logged in
        updateUIForLoggedInUser(currentUser);
    }
    
    // Function to update UI for logged in users
    function updateUIForLoggedInUser(email) {
        // Get user info
        const users = JSON.parse(localStorage.getItem('users') || '[]');
        const user = users.find(u => u.email === email);
        
        if (user) {
            // Update UI elements if they exist
            const userNameElements = document.querySelectorAll('.user-name');
            userNameElements.forEach(el => {
                el.textContent = user.name || email;
            });
            
            // Show user-only elements
            const userOnlyElements = document.querySelectorAll('.user-only');
            userOnlyElements.forEach(el => {
                el.style.display = 'block';
            });
            
            // Hide guest-only elements
            const guestOnlyElements = document.querySelectorAll('.guest-only');
            guestOnlyElements.forEach(el => {
                el.style.display = 'none';
            });
            
            // Update login button if it exists
            const loginLinks = document.querySelectorAll('a[href="login.html"]');
            loginLinks.forEach(link => {
                link.textContent = 'Logout';
                link.setAttribute('href', '#');
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    logoutUser();
                });
            });
        }
    }
    
    // Function to handle user logout
    function logoutUser() {
        // Remove current user from localStorage
        localStorage.removeItem('currentUser');
        
        // Log the activity
        logUserActivity("User logged out", "auth_activity");
        
        // Redirect to home page
        window.location.href = "index.html";
    }

    // Load transactions from localStorage or initialize empty array
    let transactions = [];
    try {
        const savedTransactions = localStorage.getItem('transactions');
        if (savedTransactions) {
            transactions = JSON.parse(savedTransactions);
        }
    } catch (error) {
        console.error("Error loading transactions from localStorage:", error);
    }

    // Save transactions to localStorage
    function saveTransactions() {
        try {
            localStorage.setItem('transactions', JSON.stringify(transactions));
        } catch (error) {
            console.error("Error saving transactions to localStorage:", error);
        }
    }

    // Form Validation for Transactions
    document.getElementById("transaction-form")?.addEventListener("submit", function (e) {
        e.preventDefault();
        const amountElement = document.getElementById("transaction-amount");
        if (!amountElement) {
            console.warn("Transaction amount field not found");
            return;
        }
        let amount = parseFloat(amountElement.value);
        if (isNaN(amount) || amount <= 0) {
            alert("Please enter a valid transaction amount.");
            return;
        }
        alert("Transaction submitted successfully!");
    });

    // Contact Form Validation
    document.getElementById("contact-form")?.addEventListener("submit", function (e) {
        e.preventDefault();
        
        // Get form data
        const name = document.getElementById("contact-name").value;
        let email = document.getElementById("contact-email").value;
        let message = document.getElementById("contact-message").value;
        
        // Basic validation
        if (!email.includes("@") || message.length < 10) {
            alert("Please enter a valid email and a longer message.");
            return;
        }
        
        // Prepare form data to send
        const formData = {
            name: name,
            email: email,
            message: message,
            timestamp: new Date().toISOString()
        };
        
        // Display sending status
        const resultElement = document.getElementById("contact-result");
        if (resultElement) {
            resultElement.innerHTML = "<div class='info-message'>Sending your message...</div>";
        }
        
        // Try to send data to the server
        fetch("http://127.0.0.1:5000/contact", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(formData)
        })
        .then(response => {
            if (response.ok) {
                return response.json();
            }
            throw new Error("Network response was not ok.");
        })
        .then(data => {
            // Show success message
            if (resultElement) {
                resultElement.innerHTML = "<div class='success-message'>Message sent successfully!</div>";
            } else {
                alert("Message sent successfully!");
            }
            
            // Log to console for verification
            console.log("Contact form submission logged:", data);
            
            // Reset the form
            e.target.reset();
        })
        .catch(error => {
            console.error("Error sending contact form:", error);
            
            // Show offline success message (since server might not be available)
            if (resultElement) {
                resultElement.innerHTML = "<div class='success-message'>Message sent successfully!</div>";
            } else {
                alert("Message sent successfully!");
            }
            
            // Log offline submission attempt
            console.log("Contact form submission (offline):", formData);
            
            // Reset the form
            e.target.reset();
        });
    });

    // Display transactions in the recent transactions section on index.html
    const transactionListElement = document.getElementById("transactionList");
    if (transactionListElement) {
        updateRecentTransactionsList();
    }

    // Function to update the recent transactions list
    function updateRecentTransactionsList() {
        if (!transactionListElement) return;
        
        // Clear the list
        transactionListElement.innerHTML = "";
        
        const noTransactionsMessage = document.getElementById("no-transactions-message");
        
        if (transactions.length === 0) {
            if (noTransactionsMessage) {
                noTransactionsMessage.style.display = "block";
            } else {
                transactionListElement.innerHTML = "<tr><td colspan='4' style='text-align:center;'>No transactions yet. Add a transaction to see it here.</td></tr>";
            }
            return;
        }
        
        if (noTransactionsMessage) {
            noTransactionsMessage.style.display = "none";
        }
        
        // Show the most recent 5 transactions
        const recentTransactions = transactions.slice(0, 5);
        
        recentTransactions.forEach(tx => {
            const row = document.createElement("tr");
            
            row.innerHTML = `
                <td>${tx.id}</td>
                <td>$${tx.amount.toFixed(2)}</td>
                <td>${tx.type}</td>
                <td><span class="status-badge ${tx.status.toLowerCase()}">${tx.status}</span></td>
            `;
            
            transactionListElement.appendChild(row);
        });
    }

    // Replace Chart.js pie chart with risk meter visualization
    const chartContainer = document.getElementById("fraudChart")?.closest('.chart-container') || document.getElementById("fraudChart");
    if (chartContainer) {
        // Calculate average risk from actual transactions
        let riskValue = 0;
        
        if (transactions.length > 0) {
            // Calculate average risk from transactions
            const totalRisk = transactions.reduce((sum, tx) => sum + tx.risk, 0);
            riskValue = Math.round(totalRisk / transactions.length);
        } else {
            // Default to low risk if no transactions
            riskValue = 10;
        }
        
        const isHighRisk = riskValue > 80;
        
        // Display risk meter instead of pie chart
        chartContainer.innerHTML = `
            <div class="risk-result ${isHighRisk ? 'high-risk' : 'low-risk'}">
                <h2>Fraud: ${isHighRisk ? 'YES' : 'NO'}</h2>
                <div class="risk-meter">
                    <div class="risk-fill" style="width: ${riskValue}%"></div>
                </div>
                <h3>Risk: ${riskValue}%</h3>
            </div>
        `;
        
        // Add some basic styles if not already in CSS
        const style = document.createElement('style');
        style.textContent = `
            .risk-meter {
                height: 30px;
                background-color: #eee;
                border-radius: 15px;
                overflow: hidden;
                margin: 10px 0;
            }
            .risk-fill {
                height: 100%;
                background: linear-gradient(90deg, green, yellow, red);
                transition: width 0.5s ease-in-out;
            }
            .high-risk { color: red; }
            .low-risk { color: green; }
        `;
        document.head.appendChild(style);
    }

    // Handle transaction form submission
    document.getElementById("transaction-form")?.addEventListener("submit", async function (event) {
        event.preventDefault();
        
        // Get form elements with null checks - use the correct IDs from HTML
        const timeEl = document.getElementById("time");
        const amountEl = document.getElementById("amount");
        const processingTimeEl = document.getElementById("processing-time");
        const typeEl = document.getElementById("transaction-type");
        const senderEl = document.getElementById("sender-account");
        const receiverEl = document.getElementById("receiver-account");
        const locationEl = document.getElementById("location");
        const deviceEl = document.getElementById("device-id");
        const ipEl = document.getElementById("ip-address");
        const prevTransEl = document.getElementById("previous-transactions");
        const accountAgeEl = document.getElementById("account-age");
        const modeEl = document.getElementById("transaction-mode");
        
        // Create transaction data object with safe access - use field names that match model
        const transactionData = {
            time: timeEl ? parseFloat(timeEl.value) : 0,
            amount: amountEl ? parseFloat(amountEl.value) : 0,
            "processing-time": processingTimeEl ? parseFloat(processingTimeEl.value) : 0,
            "transaction-type": typeEl ? typeEl.value : "",
            "sender-account": senderEl ? senderEl.value : "",
            "receiver-account": receiverEl ? receiverEl.value : "",
            location: locationEl ? locationEl.value : "",
            "device-id": deviceEl ? deviceEl.value : "",
            "ip-address": ipEl ? ipEl.value : "",
            "previous-transactions": prevTransEl ? parseInt(prevTransEl.value) : 0,
            "account-age": accountAgeEl ? parseInt(accountAgeEl.value) : 0,
            "transaction-mode": modeEl ? modeEl.value : ""
        };

        try {
            // Check if backend server is available before fetching
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 5000); // 5 second timeout
            
            let fraudResult;
            
            try {
                const response = await fetch("http://127.0.0.1:5000/predict", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(transactionData),
                    signal: controller.signal
                });
                
                clearTimeout(timeoutId);
                fraudResult = await response.json();
            } catch (error) {
                console.log("Fraud detection API unavailable, using simulation");
                // Use local simulation instead
                fraudResult = simulateFraudDetectionForTransaction(transactionData);
            }
            
            // Add transaction to the list
            const newTransaction = addNewTransaction(transactionData, fraudResult);
            
            // Save transactions to localStorage
            saveTransactions();
            
            // Update the transaction list
            updateRecentTransactionsList();
            
            // Show result in fraud-result element if present
            const fraudResultElement = document.getElementById("fraud-result");
            if (fraudResultElement) {
                const riskPercentage = fraudResult.risk_percentage || 
                    (fraudResult.probability ? Math.round(fraudResult.probability * 100) : 0);
                    
                const fraudAnswer = fraudResult.fraud === 1 ? "YES" : "NO";
                
                fraudResultElement.innerHTML = `<strong>Fraud: ${fraudAnswer}</strong><br>Risk: ${riskPercentage}%`;
                fraudResultElement.style.color = fraudResult.fraud === 1 ? "red" : "green";
            }
            
        } catch (error) {
            console.error("Error:", error);
        }
    });

    // Create function to get next transaction ID
    function getNextTransactionId() {
        if (transactions.length === 0) {
            return "TX10001";
        }
        
        // Find the highest ID number
        const highestId = transactions.reduce((max, tx) => {
            const idNum = parseInt(tx.id.substring(2));
            return idNum > max ? idNum : max;
        }, 0);
        
        // Return the next ID
        return "TX" + (highestId + 1).toString().padStart(5, '0');
    }

    // Function to add a new transaction to the list
    function addNewTransaction(transactionData, result) {
        // Create new transaction ID
        const newId = getNextTransactionId();
        
        // Determine status based on fraud detection result
        const isFraud = result.fraud === 1;
        const status = isFraud ? "Fraud" : "Safe";
        const riskPercentage = result.risk_percentage || 
            (result.probability ? Math.round(result.probability * 100) : 0);
        
        // Create the new transaction object
        const newTransaction = {
            id: newId,
            amount: transactionData.amount || 0,
            type: transactionData["transaction-type"] || "Transfer",
            sender: transactionData["sender-account"] || "Unknown",
            receiver: transactionData["receiver-account"] || "Unknown",
            timestamp: new Date().toLocaleString('en-US', { 
                year: 'numeric', 
                month: '2-digit', 
                day: '2-digit',
                hour: '2-digit',
                minute: '2-digit'
            }).replace(',', ''),
            status: status,
            risk: riskPercentage
        };
        
        // Add to the transactions array (at the beginning for newest first)
        transactions.unshift(newTransaction);
        
        return newTransaction;
    }

    // Handle add transaction form submission
    document.getElementById("add-transaction-form")?.addEventListener("submit", async function (event) {
        event.preventDefault();
        
        // Get form elements with null checks
        const timeEl = document.getElementById("time");
        const amountEl = document.getElementById("amount");
        const processingTimeEl = document.getElementById("processing-time");
        const typeEl = document.getElementById("transaction-type");
        const senderEl = document.getElementById("sender-account");
        const receiverEl = document.getElementById("receiver-account");
        const locationEl = document.getElementById("location");
        const deviceEl = document.getElementById("device-id");
        const ipEl = document.getElementById("ip-address");
        const prevTransEl = document.getElementById("previous-transactions");
        const accountAgeEl = document.getElementById("account-age");
        const modeEl = document.getElementById("transaction-mode");
        
        // Create transaction data object
        const transactionData = {
            time: timeEl ? parseFloat(timeEl.value) : 0,
            amount: amountEl ? parseFloat(amountEl.value) : 0,
            "processing-time": processingTimeEl ? parseFloat(processingTimeEl.value) : 0,
            "transaction-type": typeEl ? typeEl.value : "",
            "sender-account": senderEl ? senderEl.value : "",
            "receiver-account": receiverEl ? receiverEl.value : "",
            location: locationEl ? locationEl.value : "",
            "device-id": deviceEl ? deviceEl.value : "",
            "ip-address": ipEl ? ipEl.value : "",
            "previous-transactions": prevTransEl ? parseInt(prevTransEl.value) : 0,
            "account-age": accountAgeEl ? parseInt(accountAgeEl.value) : 0,
            "transaction-mode": modeEl ? modeEl.value : ""
        };

        try {
            // First, try to check for fraud via API
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 5000); // 5 second timeout
            
            let fraudResult = null;
            
            try {
                const response = await fetch("http://127.0.0.1:5000/predict", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(transactionData),
                    signal: controller.signal
                });
                
                clearTimeout(timeoutId);
                fraudResult = await response.json();
            } catch (error) {
                console.log("Fraud detection API unavailable, using simulation");
                // Use local simulation instead
                fraudResult = simulateFraudDetectionForTransaction(transactionData);
            }
            
            // Create a new transaction object
            const newTransaction = createTransactionFromData(transactionData, fraudResult);
            
            // Add to transactions array
            transactions.unshift(newTransaction);
            
            // Save transactions to localStorage
            saveTransactions();
            
            // Update the recent transactions list in the home page
            updateRecentTransactionsList();
            
            // Show success message
            const resultElement = document.getElementById("transaction-result");
            if (resultElement) {
                resultElement.innerHTML = `
                    <div class="success-message">
                        <h3>Transaction Added Successfully!</h3>
                        <p>Transaction ID: ${newTransaction.id}</p>
                        <p>Amount: $${newTransaction.amount.toFixed(2)}</p>
                        <p>Fraud Status: <span class="${newTransaction.status.toLowerCase()}">${newTransaction.status}</span></p>
                        <p>Risk: ${newTransaction.risk}%</p>
                        <a href="transactions.html" class="view-link">View in Transaction History</a>
                    </div>
                `;
            }
            
            // Clear the form
            event.target.reset();
        } catch (error) {
            console.error("Error adding transaction:", error);
            
            // Show error message
            const resultElement = document.getElementById("transaction-result");
            if (resultElement) {
                resultElement.innerHTML = `<div class="error-message">Error adding transaction: ${error.message}</div>`;
            }
        }
    });
    
    // Function to simulate fraud detection for new transactions
    function simulateFraudDetectionForTransaction(transactionData) {
        // Get detection rules if they exist
        const detectionRules = loadDetectionRules();
        
        // Extract data
        const time = transactionData.time || 0;
        const amount = transactionData.amount || 0;
        const processingTime = transactionData["processing-time"] || 0;
        const transactionType = transactionData["transaction-type"] || "";
        const senderAccount = transactionData["sender-account"] || "";
        const receiverAccount = transactionData["receiver-account"] || "";
        const location = transactionData["location"] || "";
        const deviceId = transactionData["device-id"] || "";
        const ipAddress = transactionData["ip-address"] || "";
        const previousTransactions = transactionData["previous-transactions"] || 0;
        const accountAge = transactionData["account-age"] || 0;
        const transactionMode = transactionData["transaction-mode"] || "";
        
        // Calculate risk percentage based on implemented rules
        let riskPercentage = 0;
        const riskFactors = {};
        
        // 1. Processing Time vs Amount Detection
        if (amount > 5000 && processingTime < 30) {
            riskPercentage += 15;
            riskFactors.fast_large_amount = true;
        }
        
        // Apply large amount threshold from rules if available
        if (detectionRules && detectionRules.flagLargeAmount) {
            const threshold = detectionRules.largeAmountThreshold || 5000;
            if (amount > threshold) {
                riskPercentage += 20;
                riskFactors.exceeds_configured_threshold = true;
            }
        } else if (amount > 5000) {
            // Default rule if no configuration
            riskPercentage += 15;
            riskFactors.large_amount = true;
        }
        
        if (amount < 100 && processingTime > 120) {
            riskPercentage += 10;
            riskFactors.slow_small_amount = true;
        }
        
        if (500 < amount && amount < 2000 && (processingTime < 10 || processingTime > 180)) {
            riskPercentage += 12;
            riskFactors.unusual_medium_timing = true;
        }
        
        // 2. Account Format Detection - apply only if validation rule is enabled
        if (!detectionRules || detectionRules.validateAccountFormat) {
            const accountPattern = /^ACC-\d{4}$/;
            if (!accountPattern.test(senderAccount)) {
                riskPercentage += 15;
                riskFactors.invalid_sender_format = true;
            }
            
            if (!accountPattern.test(receiverAccount)) {
                riskPercentage += 15;
                riskFactors.invalid_receiver_format = true;
            }
        }
        
        // 3. Late night transaction check - apply only if night transaction rule is enabled
        if (!detectionRules || detectionRules.flagNightTransactions) {
            const lateNightStart = 23 * 3600;  // 11 PM
            const lateNightEnd = 5 * 3600;     // 5 AM
            const isLateNight = (time >= lateNightStart) || (time <= lateNightEnd);
            
            if (isLateNight) {
                riskPercentage += 10;
                riskFactors.late_night_transaction = true;
                
                if (amount > 5000) {
                    riskPercentage += 15;
                    riskFactors.large_night_transaction = true;
                }
            }
        }
        
        // 4. Transaction sequence anomaly detection
        if (!detectionRules || detectionRules.flagRapidSuccession) {
            // Check for rapid succession of transactions (would be more sophisticated in a real system)
            if (previousTransactions > 5 && processingTime < 30) {
                riskPercentage += 20;
                riskFactors.rapid_succession = true;
            }
        }
        
        // 5. New account with large transaction
        if (accountAge < 30 && amount > 3000) {
            riskPercentage += 25;
            riskFactors.new_account_large_transaction = true;
        }
        
        // 6. Location-based risk assessment
        if (location === "international") {
            riskPercentage += 15;
            riskFactors.international_transaction = true;
            
            // Additional risk for international transactions from new accounts
            if (accountAge < 90) {
                riskPercentage += 10;
                riskFactors.new_account_international = true;
            }
        }
        
        // 7. IP Address anomaly detection
        if (ipAddress && !ipAddress.startsWith("192.168.")) {
            // Non-local IP addresses get additional scrutiny
            riskPercentage += 5;
            riskFactors.non_local_ip = true;
        }
        
        // 8. Transaction mode risk factors
        if (transactionMode === "Mobile" && amount > 3000) {
            riskPercentage += 7;
            riskFactors.large_mobile_transaction = true;
        }
        
        // 9. Device ID analysis
        if (!deviceId.startsWith("DEV")) {
            riskPercentage += 12;
            riskFactors.invalid_device_id = true;
        }
        
        // 10. Apply machine learning model simulation only if ML is enabled
        if (!detectionRules || detectionRules.useMlModel) {
            // Simulate ML model prediction based on combined features
            // In a real system, this would call a trained ML model
            const mlRiskContribution = calculateMlRiskContribution(
                amount, 
                time, 
                processingTime, 
                location, 
                previousTransactions, 
                accountAge
            );
            
            riskPercentage += mlRiskContribution;
            riskFactors.ml_model_contribution = true;
        }
        
        // Cap risk percentage at 100%
        riskPercentage = Math.min(100, riskPercentage);
        
        // Determine fraud based on risk percentage threshold (60%)
        const isFraud = riskPercentage > 60;
        
        return {
            fraud: isFraud ? 1 : 0,
            probability: riskPercentage / 100,
            risk_percentage: riskPercentage,
            risk_factors: riskFactors,
            contextual_insights: generateContextualInsights(riskFactors, transactionData)
        };
    }
    
    // Function to calculate ML model risk contribution
    function calculateMlRiskContribution(amount, time, processingTime, location, previousTransactions, accountAge) {
        // Simple formula to simulate ML model output
        // In a real system, this would be an actual ML model prediction
        
        // Base risk
        let mlRisk = 10;
        
        // Amount factor: higher amounts have higher risk
        const amountFactor = Math.min(25, amount / 400);
        
        // Time factor: late night has higher risk (time is in seconds from midnight)
        const hourOfDay = (time / 3600) % 24;
        const timeFactor = (hourOfDay >= 23 || hourOfDay <= 5) ? 15 : 0;
        
        // Processing time factor: very fast or very slow is suspicious
        const processingFactor = (processingTime < 10 || processingTime > 180) ? 10 : 0;
        
        // Location factor: international has higher risk
        const locationFactor = (location === "international") ? 20 : 0;
        
        // Account history factors
        const historyFactor = Math.max(0, 15 - previousTransactions) + Math.max(0, 15 - accountAge/30);
        
        mlRisk += amountFactor + timeFactor + processingFactor + locationFactor + historyFactor;
        
        return Math.min(50, mlRisk); // Cap ML contribution at 50%
    }
    
    // Function to generate contextual insights from risk factors
    function generateContextualInsights(riskFactors, transactionData) {
        const insights = [];
        
        if (riskFactors.fast_large_amount || riskFactors.large_amount || riskFactors.exceeds_configured_threshold) {
            insights.push("Transaction amount is unusually large and processed quickly, which matches patterns seen in fraud cases.");
        }
        
        if (riskFactors.invalid_sender_format || riskFactors.invalid_receiver_format) {
            insights.push("Account number format is invalid, suggesting potential attempt to bypass validation checks.");
        }
        
        if (riskFactors.late_night_transaction) {
            insights.push("Transaction occurred during late night hours when legitimate banking activity is less common.");
        }
        
        if (riskFactors.large_night_transaction) {
            insights.push("Large transactions during late night hours match known fraud patterns.");
        }
        
        if (riskFactors.rapid_succession) {
            insights.push("Multiple transactions in rapid succession may indicate automated fraud attempts.");
        }
        
        if (riskFactors.new_account_large_transaction) {
            insights.push("New accounts making large transactions are associated with higher fraud risk.");
        }
        
        if (riskFactors.international_transaction) {
            insights.push("International transactions have higher risk profiles and require additional verification.");
        }
        
        if (riskFactors.new_account_international) {
            insights.push("New accounts making international transfers match known fraud patterns.");
        }
        
        return insights;
    }
    
    // Function to load detection rules from localStorage
    function loadDetectionRules() {
        try {
            const savedRules = localStorage.getItem('detectionRules');
            if (savedRules) {
                return JSON.parse(savedRules);
            }
        } catch (error) {
            console.error("Error loading detection rules:", error);
        }
        
        // Default rules if none found
        return {
            flagLargeAmount: true,
            largeAmountThreshold: 5000,
            flagNightTransactions: true,
            flagRapidSuccession: true,
            rapidSuccessionMinutes: 5,
            validateAccountFormat: true,
            useMlModel: true
        };
    }

    // Function to create a transaction object from form data and fraud result
    function createTransactionFromData(transactionData, fraudResult) {
        // Get the next transaction ID
        const newId = getNextTransactionId();
        
        // Determine fraud status
        const isFraud = fraudResult?.fraud === 1 || false;
        const risk = fraudResult?.risk_percentage || 
                   (fraudResult?.probability ? Math.round(fraudResult.probability * 100) : 0);
        
        // Format current time
        const now = new Date();
        const timestamp = now.toLocaleString('en-US', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit'
        }).replace(',', '');
        
        // Create transaction object
        const transaction = {
            id: newId,
            amount: transactionData.amount || 0,
            type: transactionData["transaction-type"] || "Transfer",
            sender: transactionData["sender-account"] || "Unknown",
            receiver: transactionData["receiver-account"] || "Unknown",
            timestamp: timestamp,
            status: isFraud ? "Fraud" : "Safe",
            risk: risk
        };
        
        // Add contextual insights from fraud detection if available
        if (fraudResult && fraudResult.contextual_insights) {
            transaction.insights = fraudResult.contextual_insights;
        }
        
        // Add risk factors for detailed examination
        if (fraudResult && fraudResult.risk_factors) {
            transaction.riskFactors = fraudResult.risk_factors;
        }
        
        return transaction;
    }

    // Expose transactions to other scripts
    window.transactions = transactions;
});
