import pickle
import pandas as pd
import numpy as np
import re

def predict_fraud(transaction_data):
    """
    Predict fraud based on outlier detection with suspicious patterns
    """
    try:
        # Load model
        with open("fraud_model.pkl", "rb") as f:
            model_info = pickle.load(f)
        
        model = model_info["model"]
        scaler = model_info["scaler"]
        encoders = model_info.get("encoders", {})
        features = model_info.get("features", [])
        categorical_columns = model_info.get("categorical_columns", [])
        risk_threshold = model_info.get("risk_threshold", 60)
        
        # Convert to DataFrame
        df = pd.DataFrame([transaction_data])
        
        # Feature engineering
        risk_factors = {}
        risk_percentage = 0
        
        # 1. Transaction Processing Time vs Amount Detection
        if "ProcessingTime" in df.columns and "Amount" in df.columns:
            processing_time = df["ProcessingTime"].values[0]
            amount = df["Amount"].values[0]
            
            # Calculate processing time per amount
            if amount > 0:
                df["ProcessingTime_per_amount"] = processing_time / amount
            else:
                df["ProcessingTime_per_amount"] = processing_time
                
            # Check for unusually fast processing for large amounts
            if amount > 5000 and processing_time < 30:
                risk_factors["fast_large_amount"] = True
                risk_percentage += 15
            
            # Check for unusually slow processing for small amounts
            if amount < 100 and processing_time > 120:
                risk_factors["slow_small_amount"] = True
                risk_percentage += 10
                
            # Check for medium transactions with unusual timing
            if 500 < amount < 2000 and (processing_time < 10 or processing_time > 180):
                risk_factors["unusual_medium_timing"] = True
                risk_percentage += 12
        
        # 2. Account Format and Outlier Detection
        account_pattern = r'^ACC-\d{4}$'
        
        if "SenderAccount" in df.columns:
            sender_account = df["SenderAccount"].values[0]
            
            # Validate account format (ACC-NNNN pattern)
            valid_sender_format = bool(re.match(account_pattern, sender_account))
            risk_factors["invalid_sender_format"] = not valid_sender_format
            if not valid_sender_format:
                risk_percentage += 15
            
            # Detect suspicious account keywords
            suspicious_keywords = ['TEST', 'TEMP', 'FRAUD', 'HACK']
            suspicious_sender = any(keyword in sender_account for keyword in suspicious_keywords)
            risk_factors["suspicious_sender_keyword"] = suspicious_sender
            if suspicious_sender:
                risk_percentage += 25
                
            # For new transactions, assume accounts with specific patterns are outliers
            # In a real system, this would check against a database of known accounts
            suspicious_account_numbers = ['9999', '0000', '1234', '7777']
            if any(num in sender_account for num in suspicious_account_numbers):
                risk_factors["rare_sender_account"] = True
                risk_percentage += 10
                
        if "ReceiverAccount" in df.columns:
            receiver_account = df["ReceiverAccount"].values[0]
            
            # Validate account format
            valid_receiver_format = bool(re.match(account_pattern, receiver_account))
            risk_factors["invalid_receiver_format"] = not valid_receiver_format
            if not valid_receiver_format:
                risk_percentage += 15
                
            # Check for suspicious keywords
            suspicious_receiver = any(keyword in receiver_account for keyword in suspicious_keywords)
            risk_factors["suspicious_receiver_keyword"] = suspicious_receiver
            if suspicious_receiver:
                risk_percentage += 25
                
            # Check for outlier receiver
            if any(num in receiver_account for num in suspicious_account_numbers):
                risk_factors["rare_receiver_account"] = True
                risk_percentage += 10
                
            # Check if sender and receiver are the same
            if "SenderAccount" in df.columns and df["SenderAccount"].values[0] == receiver_account:
                risk_factors["self_transfer"] = True
                risk_percentage += 20
        
        # 3. IP Address Outlier Detection
        if "IP_Address" in df.columns:
            ip_address = df["IP_Address"].values[0]
            
            # Check for suspicious IP patterns (internal networks, reserved ranges)
            suspicious_ip_prefixes = ['10.', '192.168.', '127.0.0.', '169.254.', '0.0.0.', 
                                     '203.0.113.', '198.51.100.', '192.0.2.']
            suspicious_ip = any(ip_address.startswith(prefix) for prefix in suspicious_ip_prefixes)
            risk_factors["suspicious_ip_pattern"] = suspicious_ip
            if suspicious_ip:
                risk_percentage += 15
                
            # In a real system, IP frequency would be checked against historical data
            # Here we'll use pattern matching for demonstration
            unusual_ip_patterns = ['.0.1', '.255.255', '.100.100', '.1.1']
            rare_ip = any(pattern in ip_address for pattern in unusual_ip_patterns)
            risk_factors["rare_ip_address"] = rare_ip
            if rare_ip:
                risk_percentage += 10
        
        # 4. Additional Amount-Related Risk Factors
        if "Amount" in df.columns:
            amount = df["Amount"].values[0]
            
            # Very large amounts
            if amount > 10000:
                risk_factors["very_large_amount"] = True
                risk_percentage += 20
            elif amount > 5000:
                risk_factors["large_amount"] = True
                risk_percentage += 10
                
            # Suspiciously round amounts
            if amount >= 1000 and amount % 1000 == 0:
                risk_factors["round_amount"] = True
                risk_percentage += 5
                
        # Cap risk percentage at 100%
        risk_percentage = min(100, risk_percentage)
        
        # Create and ensure all required features for the model
        for col in features:
            if col not in df.columns:
                df[col] = 0
        
        # Apply encoders on categorical columns
        for col in categorical_columns:
            if col in df.columns and col in encoders:
                try:
                    df[col] = encoders[col].transform(df[col].astype(str))
                except:
                    # If value is unknown, use a default value
                    df[col] = 0
        
        # Get model features in the right order
        X = df[features]
        
        # Scale features
        try:
            X_scaled = scaler.transform(X)
            
            # Get model prediction
            model_pred = model.predict(X_scaled)[0]
            model_prob = model.predict_proba(X_scaled)[0, 1] * 100  # Convert to percentage
            
            # Blend rule-based risk with model probability
            blended_risk = (risk_percentage * 0.7) + (model_prob * 0.3)
            
            # Final risk percentage (capped at 100)
            risk_percentage = min(100, blended_risk)
        except Exception as e:
            # If model prediction fails, use only rule-based risk
            print(f"Model prediction error: {e}")
            model_pred = 0
            model_prob = 0
            
        # Determine fraud status based on risk percentage threshold
        is_fraud = risk_percentage > risk_threshold
            
        # Determine risk level
        if risk_percentage >= 80:
            risk_level = "Very High"
        elif risk_percentage >= 60:
            risk_level = "High"
        elif risk_percentage >= 40:
            risk_level = "Medium"
        elif risk_percentage >= 20:
            risk_level = "Low"
        else:
            risk_level = "Very Low"
        
        return {
            "fraud": int(is_fraud),
            "probability": float(model_prob),
            "risk_percentage": float(risk_percentage),
            "risk_level": risk_level,
            "risk_factors": risk_factors
        }
        
    except Exception as e:
        import traceback
        return {"error": str(e), "traceback": traceback.format_exc()}

if __name__ == "__main__":
    # Test with sample transaction
    sample = {
        "Amount": 7500.0,
        "ProcessingTime": 15,  # Suspiciously fast for large amount
        "TransactionType": "Transfer",
        "SenderAccount": "ACC-9999",  # Suspicious account number
        "ReceiverAccount": "ACC-TEST",  # Invalid format and suspicious keyword
        "IP_Address": "192.168.1.1",   # Internal IP (suspicious for banking)
        "DeviceID": "DEV-XYZ",
        "Location": "international"
    }
    
    result = predict_fraud(sample)
    print(f"Fraud Detection Result: {result}")
