import pickle
import pandas as pd
import numpy as np
import re
from flask import Flask, request, jsonify
from flask_cors import CORS

# Load trained model and preprocessing tools
try:
    with open("fraud_model.pkl", "rb") as model_file:
        data = pickle.load(model_file)
        model = data["model"]
        scaler = data["scaler"]
        encoders = data["encoders"]
        features = data["features"]
        categorical_columns = data["categorical_columns"]
    print("✅ Model loaded successfully")
except Exception as e:
    print(f"❌ Error loading model: {e}")
    # Provide fallback for testing
    model, scaler, encoders, features, categorical_columns = None, None, {}, [], []

# Initialize Flask app
app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

@app.route("/", methods=["GET"])
def home():
    return jsonify({
        "status": "online",
        "message": "Fraud Detection API is running",
        "model_loaded": model is not None
    })

# Define API Route for fraud prediction
@app.route("/predict", methods=["POST"])
def predict():
    try:
        # Get JSON data from frontend
        transaction_data = request.json
        print(f"Received transaction data: {transaction_data}")
        
        # Convert to DataFrame
        df = pd.DataFrame([transaction_data])
        
        # Feature engineering - match fields from the form
        # 1. Make sure Amount is handled as float
        if "amount" in df.columns:
            df["Amount"] = df["amount"].astype(float)
            print(f"Found amount field: {df['amount'].values[0]} → {df['Amount'].values[0]}")
        elif "Amount" in df.columns:
            df["Amount"] = df["Amount"].astype(float)
            print(f"Found Amount field: {df['Amount'].values[0]}")
        else:
            print("WARNING: No amount field found in request")
        
        # Make sure processing time is handled as float or int
        if "processing-time" in df.columns:
            df["ProcessingTime"] = df["processing-time"].astype(float)
            print(f"Found processing time field: {df['ProcessingTime'].values[0]}")
        elif "ProcessingTime" in df.columns:
            df["ProcessingTime"] = df["ProcessingTime"].astype(float)
        else:
            # Default processing time based on amount (larger amounts take longer)
            if "Amount" in df.columns:
                df["ProcessingTime"] = 30 + (df["Amount"] / 1000)
                print(f"Estimated processing time: {df['ProcessingTime'].values[0]:.2f} seconds")
            else:
                df["ProcessingTime"] = 60  # Default processing time
        
        # 2. Handle different field names that might come from the form
        field_mappings = {
            # HTML form field IDs from index.html and detect.html
            "time": "Time",
            "amount": "Amount",
            "processing-time": "ProcessingTime",
            "transaction-type": "TransactionType", 
            "sender-account": "SenderAccount",
            "receiver-account": "ReceiverAccount",
            "location": "Location",
            "device-id": "DeviceID",
            "ip-address": "IP_Address",
            "previous-transactions": "PreviousTransactionCount",
            "account-age": "AccountAge",
            "transaction-mode": "TransactionMode"
        }
        
        # Standardize field names
        for form_field, model_field in field_mappings.items():
            if form_field in df.columns and model_field not in df.columns:
                df[model_field] = df[form_field]
                print(f"Mapped '{form_field}' → '{model_field}': {df[form_field].values[0]}")
        
        print(f"Available model-ready fields: {list(df.columns)}")
        
        # 3. Create frequency features (use low values for new transactions)
        for field in ["SenderAccount", "ReceiverAccount", "IP_Address", "DeviceID"]:
            if field in df.columns:
                df[f"{field}_freq"] = 0.001  # Assume rare value for new transactions
                print(f"Created frequency feature: {field}_freq")
        
        # 4. PRIMARY FRAUD DETECTION: Time, Amount, and Processing Time Based
        fraud_detected = False
        fraud_probability = 0.0
        risk_percentage = 0.0
        risk_factors = {}
        
        # 4.1 Time and Amount Based Detection
        if "Time" in df.columns and "Amount" in df.columns:
            time_value = df["Time"].values[0]
            amount = df["Amount"].values[0]
            
            # Define time periods (in seconds)
            late_night_start = 23 * 3600  # 11 PM
            late_night_end = 5 * 3600     # 5 AM
            
            # Time-based risk factors
            is_late_night = (time_value >= late_night_start) or (time_value <= late_night_end)
            is_exact_hour = time_value % 3600 == 0
            is_exact_minute = time_value % 60 == 0 and time_value % 3600 != 0
            
            # Amount-based risk factors
            is_large_amount = amount > 5000
            is_small_amount = amount < 100
            
            # PRIMARY TIME-AMOUNT PATTERNS
            # Pattern 1: Late night small transactions (testing before big fraud)
            time_amount_pattern1 = is_late_night and is_small_amount
            # Pattern 2: Large exact-time transactions (potentially automated)
            time_amount_pattern2 = (is_exact_hour or is_exact_minute) and is_large_amount
            # Pattern 3: Very large late-night transactions
            time_amount_pattern3 = is_late_night and amount > 10000
            # Pattern 4: Multiple of 1000 amount (suspicious round number)
            time_amount_pattern4 = amount >= 1000 and amount % 1000 == 0
            
            # Store time-amount risk factors
            risk_factors["late_night_transaction"] = int(is_late_night)
            risk_factors["exact_time_transaction"] = int(is_exact_hour or is_exact_minute)
            risk_factors["small_amount_unusual_time"] = int(time_amount_pattern1)
            risk_factors["automated_large_transfer"] = int(time_amount_pattern2)
            risk_factors["large_night_transaction"] = int(time_amount_pattern3)
            risk_factors["suspicious_round_amount"] = int(time_amount_pattern4)
            
            # Calculate time-amount risk percentage
            time_amount_risk = (
                (15 if time_amount_pattern1 else 0) +
                (20 if time_amount_pattern2 else 0) +
                (25 if time_amount_pattern3 else 0) +
                (10 if time_amount_pattern4 else 0)
            )
            
            risk_percentage += time_amount_risk
            
            # If any primary pattern matches, flag as potential fraud
            if time_amount_risk > 0:
                fraud_probability += time_amount_risk / 100
                print(f"Primary fraud detection: Time-Amount patterns detected with risk {time_amount_risk}%")
        else:
            print("WARNING: Missing Time or Amount fields for primary fraud detection")
            
        # 4.2 Processing Time vs Amount Detection
        if "ProcessingTime" in df.columns and "Amount" in df.columns:
            processing_time = df["ProcessingTime"].values[0]
            amount = df["Amount"].values[0]
            
            # Check for unusually fast processing for large amounts
            if amount > 5000 and processing_time < 30:
                risk_factors["fast_large_amount"] = 1
                risk_percentage += 15
                fraud_probability += 0.15
                print(f"Suspicious: Fast processing time ({processing_time}s) for large amount (${amount})")
            
            # Check for unusually slow processing for small amounts
            if amount < 100 and processing_time > 120:
                risk_factors["slow_small_amount"] = 1
                risk_percentage += 10
                fraud_probability += 0.10
                print(f"Suspicious: Slow processing time ({processing_time}s) for small amount (${amount})")
                
            # Check for medium transactions with unusual timing
            if 500 < amount < 2000 and (processing_time < 10 or processing_time > 180):
                risk_factors["unusual_medium_timing"] = 1
                risk_percentage += 12
                fraud_probability += 0.12
                print(f"Suspicious: Unusual processing time ({processing_time}s) for medium amount (${amount})")
        
        # 5. SECONDARY FRAUD DETECTION: IP Address
        if "IP_Address" in df.columns:
            ip_address = df["IP_Address"].values[0]
            
            # Define suspicious IP patterns
            suspicious_ips = [
                "192.168.0.", # Local network (suspicious for banking)
                "10.0.0.",    # Local network (suspicious for banking)
                "203.0.113.", # TEST-NET-3 block (suspicious)
                "198.51.100.", # TEST-NET-2 block (suspicious)
                "192.0.2.",   # TEST-NET-1 block (suspicious)
                "127.0.0.",   # Localhost (suspicious)
                "169.254.",   # Link-local (suspicious)
                "0.0.0."      # Invalid (suspicious)
            ]
            
            ip_suspicious = any(ip_address.startswith(sus_ip) for sus_ip in suspicious_ips)
            
            # Identify rare IP addresses as potential outliers
            unusual_ip_patterns = ['.0.1', '.255.255', '.100.100', '.1.1']
            rare_ip = any(pattern in ip_address for pattern in unusual_ip_patterns)
            
            # Add IP risk factors
            risk_factors["suspicious_ip_pattern"] = int(ip_suspicious)
            risk_factors["rare_ip_address"] = int(rare_ip)
            
            # Adjust risk percentage based on IP
            if ip_suspicious:
                risk_percentage += 15
                fraud_probability += 0.15
                print(f"Secondary fraud detection: Suspicious IP pattern detected")
                
            if rare_ip:
                risk_percentage += 10
                fraud_probability += 0.10
                print(f"Secondary fraud detection: Rare IP address pattern detected")
        
        # 6. SECONDARY FRAUD DETECTION: Account Information
        account_pattern = r'^ACC-\d{4}$'
        
        if "SenderAccount" in df.columns:
            sender = df["SenderAccount"].values[0]
            
            # Validate account format (ACC-NNNN pattern)
            valid_sender_format = bool(re.match(account_pattern, sender))
            risk_factors["invalid_sender_format"] = int(not valid_sender_format)
            
            if not valid_sender_format:
                risk_percentage += 15
                fraud_probability += 0.15
                print(f"Suspicious: Invalid sender account format: {sender}")
            
            # Check for suspicious account patterns
            suspicious_accounts = [
                "9999", "8888", "7777", "0000",  # Example suspicious account numbers
                "TEMP", "TEST", "FRAUD", "HACK"  # Suspicious keywords
            ]
            
            sender_suspicious = any(sus_acc in sender for sus_acc in suspicious_accounts)
            risk_factors["suspicious_sender"] = int(sender_suspicious)
            
            if sender_suspicious:
                risk_percentage += 25
                fraud_probability += 0.25
                print(f"Suspicious: Sender account contains suspicious pattern: {sender}")
                
        if "ReceiverAccount" in df.columns:
            receiver = df["ReceiverAccount"].values[0]
            
            # Validate account format
            valid_receiver_format = bool(re.match(account_pattern, receiver))
            risk_factors["invalid_receiver_format"] = int(not valid_receiver_format)
            
            if not valid_receiver_format:
                risk_percentage += 15
                fraud_probability += 0.15
                print(f"Suspicious: Invalid receiver account format: {receiver}")
            
            # Check for suspicious patterns in receiver
            receiver_suspicious = any(sus_acc in receiver for sus_acc in suspicious_accounts)
            risk_factors["suspicious_receiver"] = int(receiver_suspicious)
            
            if receiver_suspicious:
                risk_percentage += 25
                fraud_probability += 0.25
                print(f"Suspicious: Receiver account contains suspicious pattern: {receiver}")
            
            # Self-transfer check
            if "SenderAccount" in df.columns:
                account_similarity = sender == receiver
                risk_factors["self_transfer"] = int(account_similarity)
                
                if account_similarity:
                    risk_percentage += 20
                    fraud_probability += 0.20
                    print(f"Suspicious: Self-transfer detected (sender = receiver)")
            
            # Additional check: New account with high amount
            if "AccountAge" in df.columns and "Amount" in df.columns:
                account_age = df["AccountAge"].values[0]
                amount = df["Amount"].values[0]
                
                new_account_high_amount = account_age < 30 and amount > 1000
                risk_factors["new_account_high_amount"] = int(new_account_high_amount)
                
                if new_account_high_amount:
                    risk_percentage += 20
                    fraud_probability += 0.20
                    print(f"Secondary fraud detection: New account ({account_age} days) with high amount (${amount})")
        
        # Cap risk percentage at 100%
        risk_percentage = min(100, risk_percentage)
        
        # Cap fraud probability at 1.0
        fraud_probability = min(1.0, fraud_probability)
        
        # Determine if transaction is fraudulent based on risk percentage (threshold 60%)
        if risk_percentage > 60:
            fraud_detected = True
            print(f"Transaction marked as fraudulent with risk percentage {risk_percentage:.2f}%")
        
        # Get risk level from risk percentage
        if risk_percentage >= 80:
            risk_level = "Very High"
        elif risk_percentage >= 60:
            risk_level = "High"
        elif risk_percentage >= 40:
            risk_level = "Medium"
        elif risk_percentage >= 20:
            risk_level = "Low"
        else:
            risk_level = "Very Low"
        
        # Use original model for additional refinement if available
        if model is not None and features:
            # Ensure all required features exist
            missing_features = []
            for col in features:
                if col not in df.columns:
                    df[col] = 0
                    missing_features.append(col)
            if missing_features:
                print(f"Added missing features with default value 0: {missing_features}")
            
            # Make sure all categorical fields are properly encoded before scaling
            categorical_fields = ["TransactionType", "Location", "TransactionMode"]
            for col in categorical_fields:
                if col in df.columns and col in encoders:
                    try:
                        print(f"Encoding {col}: {df[col].values[0]}")
                        df[col] = encoders[col].transform(df[col])
                        print(f"Encoded {col}: {df[col].values[0]}")
                    except Exception as e:
                        print(f"Warning: Couldn't encode {col}: {e}. Using default value 0")
                        df[col] = 0
                
            # Apply feature preparation and make prediction
            model_df = df[features]
            
            # Verify data types before scaling
            for col in model_df.columns:
                try:
                    model_df[col] = model_df[col].astype(float)
                except Exception as e:
                    print(f"Warning: Column {col} couldn't be converted to float: {e}. Using zeros.")
                    model_df[col] = 0.0
                    
            print(f"Model dataframe dtypes: {model_df.dtypes}")
            
            try:
                X_scaled = scaler.transform(model_df)
                model_prediction = int(model.predict(X_scaled)[0])
                model_probability = float(model.predict_proba(X_scaled)[0, 1])
                
                # Blend model prediction with rule-based detection
                # If our rule-based system detected fraud but model didn't, trust our rules but reduce confidence
                if fraud_detected and model_prediction == 0:
                    risk_percentage = max(60, risk_percentage * 0.9)
                    print("Rule-based fraud detection overriding model (with reduced confidence)")
                # If model detected fraud but our rules didn't, accept model's decision with moderate confidence
                elif not fraud_detected and model_prediction == 1:
                    fraud_detected = True
                    risk_percentage = max(risk_percentage, model_probability * 100)
                    print("Model fraud detection complementing rules")
                # If both agree on fraud, use higher confidence value
                elif fraud_detected and model_prediction == 1:
                    risk_percentage = max(risk_percentage, model_probability * 100)
                    print("Model and rules agree on fraud")
                # If both agree it's not fraud, use rule-based probability (likely low)
                else:
                    print("Model and rules agree on no fraud")
            except Exception as e:
                print(f"Warning: Error during model prediction: {e}. Using rule-based detection only.")
                # Continue with only rule-based detection
        
        # Final fraud prediction
        fraud_prediction = 1 if fraud_detected or risk_percentage >= 60 else 0
        
        # Return results
        response = {
            "fraud": fraud_prediction,
            "probability": float(fraud_probability),
            "risk_percentage": float(risk_percentage),
            "risk_level": risk_level,
            "amount": float(df["Amount"].values[0]) if "Amount" in df.columns else 0,
            "risk_factors": risk_factors
        }
        
        print(f"Response: {response}")
        return jsonify(response)

    except Exception as e:
        import traceback
        error_response = {
            "error": str(e),
            "traceback": traceback.format_exc(),
            "request_data": transaction_data if 'transaction_data' in locals() else "No data"
        }
        print(f"Error: {error_response}")
        return jsonify(error_response), 400

# Endpoint to get transaction history (for transactions.html)
@app.route("/transactions", methods=["GET"])
def get_transactions():
    # In a real application, this would fetch from a database
    # Here we'll generate some example transactions
    import random
    from datetime import datetime, timedelta
    
    transactions = []
    
    # Generate 50 random transactions for demonstration
    for i in range(50):
        amount = round(random.uniform(10, 10000), 2)
        types = ['Credit', 'Debit', 'Transfer']
        transaction_type = random.choice(types)
        
        # Generate a date within the last 30 days
        date = datetime.now() - timedelta(days=random.randint(0, 30))
        timestamp = date.strftime("%m/%d/%Y %I:%M %p")
        
        # Generate fraud probability - higher amounts more likely to be fraudulent
        is_fraud = random.random() < (0.4 if amount > 5000 else 0.2 if amount > 1000 else 0.05)
        risk_percentage = random.randint(70, 100) if is_fraud else random.randint(1, 30)
        
        transaction = {
            "id": f"TX{78923 - i:05d}",
            "amount": amount,
            "type": transaction_type,
            "sender": f"ACC-{random.randint(1000, 9999)}",
            "receiver": f"ACC-{random.randint(1000, 9999)}",
            "timestamp": timestamp,
            "status": "Fraud" if is_fraud else "Safe",
            "risk": risk_percentage
        }
        
        transactions.append(transaction)
    
    # Sort by newest first (based on ID)
    transactions.sort(key=lambda x: int(x["id"][2:]), reverse=True)
    
    return jsonify(transactions)

# Run Flask server
if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
